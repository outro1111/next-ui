import Dashboard from './dashboard/page';

export default function MoviesPage() {
  return (
    <>
      <Dashboard />
    </>
  );
}

export const metadata = {
  title: "Cellink | Dashboard",
  description: "Dashboard",
}